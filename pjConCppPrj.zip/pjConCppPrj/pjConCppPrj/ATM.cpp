#include "ATM_libr.h"

void main()
{
	                          //        created by:    YASHAR AKISH     //

	client Tab[200];
	history TabH[500];
	short choice, IndexOfAccount, sizeOfTab,i;
	int Deposit, Withdraw;

	do
	{
		system("cls");
		DisplayTitle("royal bank", "Automated Teller Machine");
		sizeOfTab = ReadTheTextFindTheSize(Tab);                                        
		IndexOfAccount = FindAndCheckTheAccount(Tab, sizeOfTab);                        
		FindAndCheckThePassword(Tab, IndexOfAccount);
		choice = ReadChoice(1, 4);
		switch (choice)
		{
		case 1:                                                                     
			Deposit = ReadDeposit(2, 20000);
			DoDeposit(Tab, IndexOfAccount, Deposit);
			ModifyTheTextFile(Tab, sizeOfTab);
			SaveHistory(Tab, IndexOfAccount, +Deposit);
			DisplayConsultation(Tab, IndexOfAccount);
			break;
		case 2:                                                                       
			Withdraw = ReadWithdrawal(Tab, IndexOfAccount, 20, 500, 20);
			DoWithdrawal(Tab, IndexOfAccount, Withdraw);
			ModifyTheTextFile(Tab, sizeOfTab);
			SaveHistory(Tab, IndexOfAccount, -Withdraw);
			DisplayConsultation(Tab, IndexOfAccount);
			break;
		case 3:                                                        
			DisplayConsultation(Tab, IndexOfAccount);
			break;
		case 4:
			i= ReadHistory(TabH);
			DisplayHistory(Tab ,TabH ,i , IndexOfAccount);
		}
	} while (choice == 1 || choice == 2 || choice == 3 || choice == 4);

	system("pause");
}