//#include<iostream>
//#include<string>
//using namespace std;
//
//void mainCAL()
//{
//
//	char  repeat;                    // repeat> YES,NO   
//	short nbVal, counter, choice;    // choice> 1,2,3,4,5     nbVal> number of variable to operate
//	float sum = 0, mult = 1, val,    // for ADD AND MULT
//		val1, val2;                // for SUB AND DIV
//
//
//	do
//	{
//		system("cls");
//		cout << "\n\t    CALCULATOR\n\t------------------\n";
//		cout << "\t by YASHAR AKISH\n";
//		cout << "  1- Addition\n  2- Division\n  3- Substraction\n  4- Multiplication\n  5- Quit\n";
//
//
//		//ENTERING THE CHOICE
//		do
//		{
//			cout << "\n Enter your choice(1-5): ";
//			cin >> choice;
//		} while (choice < 1 || choice > 5);
//
//		//DOING THE OPERATIONS ACCORDING TO CHIOCEN ITEM
//		switch (choice)
//		{
//		case 1:  //ADDITION operation
//			do
//			{
//				system("cls");
//				sum = 0;  //for making sum 'zero' again after asking the repeatation
//				cout << "\n\tCALCULATOR\n-------------------------\n";
//				cout << "\tAddition\n";
//				do
//				{
//					cout << "\n  Enter the number of values to add (max 100 number): ";
//					cin >> nbVal;
//
//				} while (nbVal > 100 || nbVal < 2);
//
//
//				for (short counter = 0; counter < nbVal; counter++)
//				{
//					cout << " value " << counter + 1 << "  :";
//					cin >> val;
//					sum += val;
//				}
//
//				cout << "\n  The result is " << sum << endl;
//
//				do
//				{
//					cout << "  Whould you like to do another Addition (Y/N): ";
//					cin >> repeat;
//				} while (repeat != 'y' && repeat != 'Y' && repeat != 'n' && repeat != 'N');
//
//
//			} while (repeat == 'y' || repeat == 'Y');
//			break;
//
//
//		case 2:  //DIVISION operation
//			do
//			{
//				system("cls");
//				cout << "\n\tCALCULATOR\n-------------------------\n";
//				cout << "\tDivision\n";
//				cout << "\n  Enter the the value to divide: ";
//				cin >> val1;
//				do
//				{
//					cout << "  Enter the divider(NOT ZERO): ";
//					cin >> val2;
//				} while (val2 == 0);
//
//				cout << "\n The result is: " << (val1 / val2) << endl;
//
//				do
//				{
//					cout << "  Whould you like to do another Division (Y/N): ";
//					cin >> repeat;
//				} while (repeat != 'y' && repeat != 'Y' && repeat != 'n' && repeat != 'N');
//
//			} while (repeat == 'y' || repeat == 'Y');
//			break;
//
//
//		case 3:  //SUBSTRACTION operation
//			do
//			{
//				system("cls");
//				cout << "\n\tCALCULATOR\n-------------------------\n";
//				cout << "\tSubstraction\n";
//				cout << "\n  Enter the the value to substract: ";
//				cin >> val1;
//				cout << "  Enter the substracter: ";
//				cin >> val2;
//
//				cout << "\n The result is: " << (val1 - val2) << endl;
//
//				do
//				{
//					cout << "  Whould you like to do another Substraction (Y/N): ";
//					cin >> repeat;
//				} while (repeat != 'y' && repeat != 'Y' && repeat != 'n' && repeat != 'N');
//
//			} while (repeat == 'y' || repeat == 'Y');
//			break;
//
//
//		case 4: //MULTIPLICATION operation
//			do
//			{
//				system("cls");
//				mult = 1;  //for making mult 'one' again after asking the repeatation
//				cout << "\n\tCALCULATOR\n-------------------------\n";
//				cout << "\tMultiplication\n";
//				do
//				{
//					cout << "\n  Enter the number of values to multipicate (max 100 number): ";
//					cin >> nbVal;
//				} while (nbVal > 100 || nbVal < 2);
//
//				for (short counter = 0; counter < nbVal; counter++)
//				{
//					cout << " value " << counter + 1 << "  :";
//					cin >> val;
//					mult *= val;
//				}
//
//				cout << "\n  The result is " << mult << endl;
//
//				do
//				{
//					cout << "  Whould you like to do another Multiplication (Y/N): ";
//					cin >> repeat;
//				} while (repeat != 'y' && repeat != 'Y' && repeat != 'n' && repeat != 'N');
//
//			} while (repeat == 'y' || repeat == 'Y');
//			break;
//
//
//		case 5:  //QUIT calculator
//
//			system("cls");
//			cout << "\n\n thank you for using this calculator\n";
//			cout << " *************************************\n\n";
//
//
//			system("pause");
//			break;
//
//		}
//
//	} while (choice != 5);
//
//}
