//#include "CalculatorLibrary.h"
//
//void main_CAL_LIB()
//{
//	short choice;
//	do
//	{
//		DisplayTitle("calculator", "by yashar akish");
//		DisplayMenu();
//		choice = ReadTheCHoice();
//
//		switch (choice)
//		{
//		case 1:
//			DisplayAddition("calculator", "addition", 100, 2, "addition"); 
//			break;
//		case 2:
//			DisplaySubtraction("calculator","subtraction","subtraction","substract","substracter");
//			break;
//		case 3:
//			DisplayMultiplication("calculator", "multiplication", 100, 2, "multiplication");
//			break;
//		case 4:
//			DisplayDivision("calculator", "division", "division","divide","divider (NOT ZERO)");
//			break;
//		case 5:
//			quit();
//		}
//	} while (choice != 5);
//}