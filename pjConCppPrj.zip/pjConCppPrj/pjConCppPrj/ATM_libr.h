#pragma once
#include<iostream>
#include<string>
#include<fstream>
#include<iomanip>
using namespace std;
                                     //        created by:    YASHAR AKISH      //
struct client
{
	string account;
	string name;
	string password;
	float balance;
};
struct history
{
	string acc;
	float change;
	float dollar;
};

void DisplayTitle(string title,string text)
{
	cout << "\n\n\t\t";
	for (short i = 0; i < title.length(); i++)
	{
		cout << (char)toupper(title[i]);
	}
	cout << "\n\t\t";
	for (short i = 0; i < title.length(); i++)
	{
		cout << "-";
	}
	cout << "\n\t";
	for (short i = 0; i < text.length(); i++)
	{
		cout << (char)toupper(text[i]);
	}
	cout << "\n\t";
	for (short i = 0; i < text.length(); i++)
	{
		cout << "-";
	}
	cout << "\n\n";
}

short ReadTheTextFindTheSize(client Tab[])                     // read the text file and creat THE  ARRAY  then return SIZE of array
{
	fstream bankfile;

	bankfile.open("ATM_File.txt", ios::in);
	short i = 0;
	while (!bankfile.eof())
	{
		getline(bankfile, Tab[i].account);
		getline(bankfile, Tab[i].name);
		getline(bankfile, Tab[i].password);
		bankfile >> Tab[i].balance;
		bankfile.ignore();
		i++;
	}
	bankfile.close();
	return i;
}

string ReadAccountNumber()
{
	string account;
	cout << "  Enter your account number: ";
	cin >> account;
	return account;
}

short FindAndCheckTheAccount(client Tab[], short sizeTab)                          // find and check the account number then return the INDEX of account
{
	string account;
	short index, k = 0;      // k   for checking wrong account number

	do
	{
		account = ReadAccountNumber();
		for (short j = 0; j < sizeTab; j++)
		{
			if (Tab[j].account == account)
			{
				cout << "\t  Wellcome     " << Tab[j].name << endl;
				k++;
				index = j;
			}
		}
		if (k == 0)
		{
			cout << "  Invalid account number" << endl;
		}
	} while (k == 0);
	return index;
}

string ReadPassword()                                                                        
{
	string pass;
	cout << "  Enter your password : ";
	cin >> pass;
	return pass;
}

void FindAndCheckThePassword(client Tab[], short index)                                                   
{
	string pass;
	short k = 0;             //     for checking wrong password

	do
	{
		pass = ReadPassword();
		if (Tab[index].password == pass)
		{
			cout << "\n   Choose your transaction:" << endl;
			cout << "\t\t1 >> Deposit\n\t\t2 >> Withdraw\n\t\t3 >> Consultation\n\t\t4 >> History" << endl;
			k++;
		}
		if (k == 0)
		{
			cout << "  Invalid Password" << endl;
		}
	} while (k == 0);
}

short ReadChoice(short mn, short mx)
{
	short ch;
	do
	{
		cout << " Enter your choice ("<<mn<<"-"<<mx<<") : ";
		cin >> ch;
	} while (ch != 4 && ch != 3 && ch != 2 && ch != 1);
	return ch;
}

int ReadDeposit(int min, int max)
{
	int money;

	do
	{
		cout << "\n  Enter the amount you want to deposit :   $ ";
		cin >> money;
	} while (money > max || money < min);
	return money;
}

void DoDeposit(client Tab[], short index, int money)
{
	Tab[index].balance = Tab[index].balance + money;
}

int ReadWithdrawal(client Tab[], short index, int min, int max, short mult)
{
	int money;

	do
	{
		cout << "\n  Enter the amount you want to withdraw :   $ ";
		cin >> money;
	} while (money > max || money < min || money % mult != 0 || money > (Tab[index].balance));
	return money;
}

void DoWithdrawal(client Tab[], short index, int money)
{
	Tab[index].balance = Tab[index].balance - money;
}

void ModifyTheTextFile(client Tab[], short sizeTab)
{
	fstream bankfile;
	bankfile.open("ATM_File.txt", ios::out);
	for (short j = 0; j < sizeTab - 1; j++)
	{
		bankfile << Tab[j].account << endl;
		bankfile << Tab[j].name << endl;
		bankfile << Tab[j].password << endl;
		bankfile << Tab[j].balance << endl;
	}
	bankfile << Tab[sizeTab - 1].account << endl;
	bankfile << Tab[sizeTab - 1].name << endl;
	bankfile << Tab[sizeTab - 1].password << endl;
	bankfile << Tab[sizeTab - 1].balance;

	bankfile.close();
	cout << "\n -->> The transaction was successfull <<-- " << endl;
}

void SaveHistory(client Tab[], short index, int money)
{
	fstream historyfile;

	historyfile.open("ClientHistory.txt", ios::app);
	historyfile << "\n";
	historyfile << Tab[index].account << endl;
	historyfile << money << endl;
	historyfile << Tab[index].balance;
	historyfile.close();
}

void DisplayConsultation(client Tab[], short index)                                        
{
	cout << "\n  The account information:" << endl;
	cout << left << setw(17) << "\taccount number" << setw(2) << ":";
	cout << "\t" << Tab[index].account << endl;
	cout << left << setw(17) << "\tname" << setw(2) << ":";
	cout << "\t" << Tab[index].name << endl;
	cout << left << setw(17) << "\tpassword" << setw(2) << ":";
	cout << "\t" << Tab[index].password << endl;
	cout << left << setw(17) << "\tbalance" << setw(2) << ":";
	cout << "\t" << fixed << showpoint << setprecision(2) << Tab[index].balance <<" $"<< endl;
	
	cout << " ===/// Thank you for using this service ///===\n\n";
	system("pause");
}

short ReadHistory(history TabH[])
{
	fstream historyfile;

	historyfile.open("ClientHistory.txt", ios::in);
	short i = 0;
	while (!historyfile.eof())
	{
		getline(historyfile, TabH[i].acc);
		historyfile >> TabH[i].change;
		historyfile >> TabH[i].dollar;
		historyfile.ignore();
		i++;
	}
	historyfile.close();
	return i;
}

void DisplayHistory(client TabC[], history TabH[], short i, short index)
{
	cout << fixed << showpoint << setprecision(2);
	cout << "\n\tTransaction Histry" << endl;
	cout << "\t-------------------" << endl;
	cout << "  account number : " << TabC[index].account << endl;
	cout << "    Initial balance :" << TabH[index].dollar <<" $"<< endl;
	for (short h = 0; h < i; h++)
	{
		if (TabH[h].acc == TabC[index].account)
		{
			cout << left <<"\t"<< setw(10) << TabH[h].change <<" $"<< endl;
			cout <<"\t"<< TabH[h].dollar <<" $"<< endl;
		}
	}
	cout << "\t-------------------\n\n" << endl;
	system("pause");
}