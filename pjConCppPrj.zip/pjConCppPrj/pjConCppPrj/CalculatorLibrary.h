//#pragma once
//#include<iostream>
//using namespace std;
//
//void DisplayTitle(string projectName, string myName)
//{
//	system("cls");
//	cout << "\n\t\t";
//	for (short i = 0; i < projectName.length(); i++)
//	{
//		cout << (char)toupper(projectName[i]);
//	}
//	cout << "\n\t\t";
//	for (short i = 0; i < projectName.length(); i++)
//	{
//		cout << "-";
//	}
//	cout << "\n\t\t";
//	for (short i = 0; i < myName.length(); i++)
//	{
//		cout << (char)toupper(myName[i]);
//	}
//	cout << "\n\n";
//}
//
//// MENU   AND  choosing  Oopperatin  and  number  of   values,   FUNCTIONS:
//
//void DisplayMenu()
//{
//	cout << "  1-Addition\n  2-Subtraction\n  3-Multiplication\n  4-Division\n  5-Quit\n";
//}
//short ReadTheCHoice()
//{
//	short choice;
//	do
//	{
//		cout << "\n    Enter your choice (1-5) : ";
//		cin >> choice;
//	} while (choice<1 || choice>5);
//	return choice;
//}
//short ReadNBValue(short maxlimit,short minlimit)
//{
//	short NBVal;
//	do
//	{
//		cout << "\n  Enter the number of values (max "<<maxlimit<<" number): ";
//		cin >> NBVal;
//	} while (NBVal > maxlimit || NBVal < minlimit);
//	return NBVal;
//}
//
//// READING     ONE _ VALUE    FUNCTION
//
//float ReadOneValueFOR_SUB_DIV(string text) 
//{
//	float val;
//	cout<<"  Enter the the value to "<<text<<" : ";
//	cin >> val;
//	return val;
//}
//float ReadOnevalueFOR_ADD_MULT(short counter)
//{
//	float val;
//	cout << " value " << counter + 1 << "  : ";
//	cin >> val;
//	return val;
//}
//
//// opperation ( + - * / )  FUNCTIONS:    
//
//float Add(short NBVal)
//{
//	float val, sum=0;
//	for (short counter = 0; counter < NBVal; counter++)
//	{
//		val = ReadOnevalueFOR_ADD_MULT(counter);
//		sum += val;
//	}
//	return sum;
//}
//float Subtract(float val1,float val2)
//{
//	float sub;
//	return sub = (val1 - val2);
//}
//float Multiply(short NBVal)
//{
//	float val, mult = 1;
//	for (short counter = 0; counter < NBVal; counter++)
//	{
//		val = ReadOnevalueFOR_ADD_MULT(counter);
//		mult *= val;
//	}
//	return mult;
//}
//float Divide(float val1, float val2)
//{
//	float div;
//	return div = (val1 / val2);
//}
//
//// repeating  and  showing  the  result  FUNCTIONS:
//
//void DisplayResult(float result)
//{
//	cout << "\n  >>>>>>>>><<<<<<<<<" << endl;
//	cout << "\n  The result is " << result << endl;
//}
//char DoAgain(string opperation)
//{
//	char repeat;
//	do
//	{
//		cout << "\n     Whould you like to do another " << opperation << " (Y/N): "; 
//		cin >> repeat;
//		repeat = toupper(repeat);
//	} while (repeat != 'Y' && repeat != 'N');
//	return repeat;
//}
//
////    DISPLAY     OPPERATIONS     FUNCTIONS
//
//void DisplayAddition(string title, string opperation, short maxLimit, short minLimit, string sameOpperation)
//{
//	short NBVal;
//	float sum=0;
//	char repeat;
//	do
//	{
//		DisplayTitle(title,opperation);
//		NBVal = ReadNBValue(maxLimit,minLimit);
//		sum = Add(NBVal);
//		DisplayResult(sum);
//		repeat = DoAgain(sameOpperation);
//	} while (repeat == 'Y');
//}
//void DisplaySubtraction(string title, string opperation, string sameOpperation,string text1,string text2)
//{
//	short NBVal;
//	float sub, val1, val2;
//	char repeat;
//	do
//	{
//		DisplayTitle(title,opperation);
//		val1 = ReadOneValueFOR_SUB_DIV(text1);
//		val2 = ReadOneValueFOR_SUB_DIV(text2);
//		sub = Subtract(val1,val2);
//		DisplayResult(sub);
//		repeat = DoAgain(sameOpperation);
//	} while (repeat == 'Y');
//}
//void DisplayMultiplication(string title, string opperation, short maxLimit, short minLimit, string sameOpperation)
//{
//	short NBVal;
//	float mult = 1;
//	char repeat;
//	do
//	{
//		DisplayTitle(title,opperation);
//		NBVal = ReadNBValue(100, 2);
//		mult = Multiply(NBVal);
//		DisplayResult(mult);
//		repeat = DoAgain(sameOpperation);
//	} while (repeat == 'Y');
//}
//void DisplayDivision(string title, string opperation, string sameOpperation, string text1, string text2)
//{
//	short NBVal;
//	float div,val1,val2;
//	char repeat;
//	do
//	{
//		DisplayTitle(title,opperation);
//		val1 = ReadOneValueFOR_SUB_DIV(text1);
//		do
//		{
//			val2 = ReadOneValueFOR_SUB_DIV(text2);
//		} while (val2 == 0);
//		div = Divide(val1,val2);
//		DisplayResult(div);
//		repeat = DoAgain(sameOpperation);
//	} while (repeat == 'Y');
//}
//
//// QUITING FUNCTION
//
//void quit()
//{
//	system("cls");
//	cout << "\n\n thank you for using this calculator\n";
//	cout << " *************************************\n\n";
//	system("pause");
//}